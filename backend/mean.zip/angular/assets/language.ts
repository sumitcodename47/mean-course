export const language = {
  eng: {
    header: "Pune's Ganapati",
    saveComment: 'Save Comment',
  },
  marathi: {
    header: 'पुण्याचे गणपती ',
    saveComment: 'कंमेंट जतन करा',
  },
};
